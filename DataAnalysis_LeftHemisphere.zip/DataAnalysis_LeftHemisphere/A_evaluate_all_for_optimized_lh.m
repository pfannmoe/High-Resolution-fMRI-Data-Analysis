%% BBR is carried out using the finger label as target region.
clear all; clc;
%%   

display_cortical_maps = 1; %1 means yes and 0 (zero) means no.

script_dir    = pwd;


subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; 

raw_data_list = {'Name_of_Folder_with_EPI_DICOMS_of_Subject_01'
	             'Name_of_Folder_with_EPI_DICOMS_of_Subject_02'
				 'Name_of_Folder_with_EPI_DICOMS_of_Subject_03'};

for j = 1:length(subject_list)
    
    subject_name       = char(subject_list(j));
    raw_data_file      = char(raw_data_list(j));
	
    if exist(sprintf('%s/%s',pwd,subject_name)) == 0
       disp('Directory structure has not been created at all.')
       pause
    end
    
    cd(sprintf('%s/%s',script_dir,subject_name));
    maindir                     = pwd;
    raw_data                    = sprintf('%s/RawData/%s',maindir,raw_data_file);
    subject                     = subject_name;

    if exist(raw_data) == 0
       disp('RawData directory has not been created.')
       pause
    end
    
%%
           finger                       = 'NAME OF EXPERIMENT (abbreviation like D1_right_hand)';
           folder_listing               = dir([raw_data '/*.dcm']);
           frame_number                 = size(folder_listing,1)
           workdir                      = sprintf('%s/workdir',maindir)
           frame_dir                    = 'frames';
           cortical_depths_for_sampling = [0 0.3 0.6]; %distance projection along normal
           functional_frame_dir         = sprintf('%s/01_%s_%s',workdir,frame_dir,finger);
           matrices_dir                 = sprintf('%s/02_%s_%s',workdir,'matrices',finger);
           subjects_dir                 = getenv('SUBJECTS_DIR');
           finger_label                 = 'lh.BA3b_Weibull_3p5sigma.label';
           
           middle_frame                 = ceil(frame_number/2);
%            range                        = [4 0 7 3];
%% Create Directory Structure for FS-FAST and the individual Finger Region 
%% Label

           if exist(sprintf('%s/%s',maindir,finger)) == 0
              system(sprintf('mkdir %s/%s',maindir,finger));
           end

           if exist(sprintf('%s/%s/bold',maindir,finger)) == 0
              system(sprintf('mkdir %s/%s/bold',maindir,finger));
           end

           if exist(sprintf('%s/%s/bold/001',maindir,finger)) == 0
              system(sprintf('mkdir %s/%s/bold/001',maindir,finger));
           end   

           if exist(sprintf('%s/%s/subjectname',maindir,finger)) == 0
              cd(sprintf('%s',maindir));
              system(sprintf('echo "%s" > ./%s/subjectname',subject,finger));
           end

           source = sprintf('%s/paradigm_sensory.par',script_dir);
           destination = sprintf('./%s/bold/001/sensory.par',finger);
           if exist(destination) == 0
              copyfile(source,destination)
           end

           if exist(sprintf('%s/%s/bold/001/f.nii.gz',maindir,finger)) == 0
              cd(sprintf('%s',raw_data)); 
              listing = dir('./')
              system(sprintf('mri_concat %s/%s --o %s/%s/bold/001/f.nii.gz',...
                              raw_data,char(listing(3).name),maindir,finger));
               
           %    system(sprintf('mri_convert %s/%s %s/%s/bold/001/f.nii.gz',...
           %                    raw_data,char(listing(3).name),maindir,finger));
           end

%           if  exist(sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)) == 0
               system(sprintf('mri_label2label --srclabel %s/fsaverage/label/%s --srcsubject fsaverage --trglabel %s --trgsubject %s --regmethod surface --hemi lh',subjects_dir,finger_label,finger_label,subject));
%           end 

           if  exist(sprintf('%s/%s_orig',maindir,finger)) == 0
               system(sprintf('cp -r %s/%s %s/%s_orig',maindir,finger,maindir,finger));
           end

 

           clear raw_data raw_data_file
%% FS-FAST preprocessing
           if  exist(sprintf('%s/%s_orig/bold/001/fmcpr.sm0.self.lh.nii.gz',maindir,finger)) == 0
               cd(sprintf('%s',maindir));
               system(sprintf('preproc-sess -s ./%s_orig -fsd bold -surface self lh -fwhm 0 -per-run -nostc -nosmooth',finger))
           end

%% Greifswald-FAST preprocessing
   
           if exist(sprintf('%s',workdir)) == 0
              system(sprintf('mkdir %s',workdir))
           end 

           if exist(sprintf('%s',functional_frame_dir)) == 0
              system(sprintf('mkdir %s',functional_frame_dir))
           end   

           for i = 1:frame_number
               if exist(sprintf('%s/f%03i.nii',functional_frame_dir,i)) == 0
                  system(sprintf('mri_convert %s/%s/bold/001/f.nii.gz %s/f%03i.nii --frame %i',maindir,finger,functional_frame_dir,i,i-1));
               end
           end

           if exist(sprintf('%s',matrices_dir)) == 0
              system(sprintf('mkdir %s',matrices_dir))
           end

           for i = 1:frame_number 
               if exist(sprintf('%s/register.f%03i.dof6.dat',matrices_dir,i)) == 0

%                system(sprintf('mkdir %s/dummy',matrices_dir));
    
%                system(sprintf('bbregister --s %s --init-header --6 --bold --mov %s/f%03i.nii --reg %s/dummy/register.f%03i_header.dof6.dat --label %s',...
%                                subject,functional_frame_dir,i,matrices_dir,i,sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)));
%                q_dummy_header = dlmread(sprintf('%s/dummy/register.f%03i_header.dof6.dat.mincost',matrices_dir,i));
%                q_dummy_header = q_dummy_header(1);

               system(sprintf('bbregister --s %s --init-coreg --6 --bold --mov %s/f%03i.nii --reg %s/register.f%03i.dof6.dat --label %s',...
                                          subject,functional_frame_dir,i,matrices_dir,i,sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)));
               q_dummy_coreg    = dlmread(sprintf('%s/register.f%03i.dof6.dat.mincost',matrices_dir,i));
               q_dummy_coreg    = q_dummy_coreg(1);
               
%                system(sprintf('bbregister --s %s --init-fsl --6 --bold --mov %s/f%03i.nii --reg %s/dummy/register.f%03i_fsl.dof6.dat --label %s',...
%                                subject,functional_frame_dir,i,matrices_dir,i,sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)));
%                q_dummy_fsl    = dlmread(sprintf('%s/dummy/register.f%03i_fsl.dof6.dat.mincost',matrices_dir,i));
%                q_dummy_fsl    = q_dummy_fsl(1);
                
%                system(sprintf('bbregister --s %s --init-rr --6 --bold --mov %s/f%03i.nii --reg %s/dummy/register.f%03i_rr.dof6.dat --label %s',...
%                                subject,functional_frame_dir,i,matrices_dir,i,sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)));
%                q_dummy_rr    = dlmread(sprintf('%s/dummy/register.f%03i_rr.dof6.dat.mincost',matrices_dir,i));
%                q_dummy_rr    = q_dummy_rr(1);
               
%                q_dummy_vector = [q_dummy_header q_dummy_coreg q_dummy_fsl q_dummy_rr];
%                [C_max,I_max] = max(q_dummy_vector);
%                case_index = 0;
%                for meaningless_index = 1:length(q_dummy_vector)
%     
%                    [C_min,I_min] = min(q_dummy_vector);
% 
%                    if q_dummy_vector(I_min) > 0.1
%                        case_index = I_min;
%                    else
%                       q_dummy_vector(I_min) =  q_dummy_vector(I_max) + 10;
%                    end 
% 
%                end
               
%                switch case_index
%                    
%                       case 1
%                       system(sprintf('mv %s/dummy/register.f%03i_header.dof6.dat %s/register.f%03i.dof6.dat',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_header.dof6.dat.log %s/register.f%03i.dof6.dat.log',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_header.dof6.dat.mincost %s/register.f%03i.dof6.dat.mincost',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_header.dof6.dat.param %s/register.f%03i.dof6.dat.param',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_header.dof6.dat.sum %s/register.f%03i.dof6.dat.sum',...
%                              matrices_dir,i,matrices_dir,i));
%                          
%                       case 2
%                       system(sprintf('mv %s/dummy/register.f%03i_coreg.dof6.dat %s/register.f%03i.dof6.dat',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_coreg.dof6.dat.log %s/register.f%03i.dof6.dat.log',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_coreg.dof6.dat.mincost %s/register.f%03i.dof6.dat.mincost',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_coreg.dof6.dat.param %s/register.f%03i.dof6.dat.param',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_coreg.dof6.dat.sum %s/register.f%03i.dof6.dat.sum',...
%                              matrices_dir,i,matrices_dir,i));
% 
%                       case 3
%                       system(sprintf('mv %s/dummy/register.f%03i_fsl.dof6.dat %s/register.f%03i.dof6.dat',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_fsl.dof6.dat.log %s/register.f%03i.dof6.dat.log',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_fsl.dof6.dat.mincost %s/register.f%03i.dof6.dat.mincost',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_fsl.dof6.dat.param %s/register.f%03i.dof6.dat.param',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_fsl.dof6.dat.sum %s/register.f%03i.dof6.dat.sum',...
%                              matrices_dir,i,matrices_dir,i));
%                          
%                       case 4
%                       system(sprintf('mv %s/dummy/register.f%03i_rr.dof6.dat %s/register.f%03i.dof6.dat',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_rr.dof6.dat.log %s/register.f%03i.dof6.dat.log',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_rr.dof6.dat.mincost %s/register.f%03i.dof6.dat.mincost',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_rr.dof6.dat.param %s/register.f%03i.dof6.dat.param',...
%                              matrices_dir,i,matrices_dir,i));
%                       system(sprintf('mv %s/dummy/register.f%03i_rr.dof6.dat.sum %s/register.f%03i.dof6.dat.sum',...
%                              matrices_dir,i,matrices_dir,i));
% 
%                       otherwise
%                       disp('This should not happen in the registration.')
%                       disp('This may signal a fundamental problem.')
%                       dlmwrite(sprintf('%s/register.f%03i.failed.dof6.dat',matrices_dir,i));
%                       pause
%                       
%                end
 

%                clear q_dummy_header q_dummy_coreg q_dummy_fsl q_dummy_rr
%                system(sprintf('rm -r %s/dummy',matrices_dir));
               end
           end

           % create variable containing all q-values
           count_tag = 0;
           for i = 1:frame_number 
               if exist(sprintf('%s/register.f%03i.dof6.dat.mincost',matrices_dir,i)) ~= 0
                  count_tag = count_tag + 1;
               end
           end
           
           if count_tag == frame_number
              for i = 1:frame_number 
                  if exist(sprintf('%s/register.f%03i.dof6.dat.mincost',matrices_dir,i)) ~= 0
                     q_dummy     = dlmread(sprintf('%s/register.f%03i.dof6.dat.mincost',matrices_dir,i));
                     q_factor(i) = q_dummy(1);
                     save(sprintf('%s/q_factors.mat',matrices_dir),'q_factor')
                  else
                     disp('This should never happen 01. The check above should avoid this problem.') 
                  end
              end

              % choose init matrix for subsequent registration initialized 
              % with this init matrix.
              load(sprintf('%s/q_factors.mat',matrices_dir))
              [C,I] = min(q_factor);
              if exist(sprintf('%s/init',matrices_dir)) == 0 
                 system(sprintf('mkdir %s/init',matrices_dir))
              end   
              
              if exist(sprintf('%s/init/register.*.dat',matrices_dir)) == 0
                 system(sprintf('cp %s/register.f%03i.dof6.dat %s/init/register.init.dof6.dat',...
                             matrices_dir,I,matrices_dir));
              end
              
              % check if registration with initiation matrix is better
              if exist(sprintf('%s/reg_using_initiation_matrix',matrices_dir)) == 0 
                 system(sprintf('mkdir %s/reg_using_initiation_matrix',matrices_dir));
              end  
   
              for i = 1:frame_number 
                  if exist(sprintf('%s/reg_using_initiation_matrix/register.f%03i.dof6.dat.mincost',matrices_dir,i)) == 0
                     system(sprintf('bbregister --s %s --init-reg %s/init/register.init.dof6.dat --6 --bold --mov %s/%s/bold/001/f.nii.gz --frame %i --reg %s/reg_using_initiation_matrix/register.f%03i.dof6.dat',...
                                 subject,matrices_dir,maindir,finger,i-1,matrices_dir,i));
                  end
              end
              
              count_tag = 0;
              for i = 1:frame_number              
                  if exist(sprintf('%s/reg_using_initiation_matrix/register.f%03i.dof6.dat.mincost',matrices_dir,i)) ~= 0
                     count_tag = count_tag + 1;
                  end
              end 
              
              if count_tag ~= frame_number
                 disp('Something went wrong during initialization with init matrix.')
                 disp('Probably some files have not been generated.')
                 disp('This probably means that some registrations have not been carried out.')
                 disp('This problem needs to be solved before continuation is possible.')
                 pause
              end   
                 
              for i = 1:frame_number 
                  q_dummy         = dlmread(sprintf('%s/reg_using_initiation_matrix/register.f%03i.dof6.dat.mincost',matrices_dir,i));
                  q_dummy         = q_dummy(1);                
                  q_factor_reg(i) = q_dummy;
              end

              for i = 1:frame_number 
                     if q_factor_reg(i) < q_factor(i) && q_factor_reg(i) > 0.1
                        system(sprintf('cp %s/reg_using_initiation_matrix/register.f%03i.dof6.dat %s/register.f%03i.dof6.dat',...
                               matrices_dir,i,matrices_dir,i));
                        system(sprintf('cp %s/reg_using_initiation_matrix/register.f%03i.dof6.dat.log %s/register.f%03i.dof6.dat.log',...
                               matrices_dir,i,matrices_dir,i));
                        system(sprintf('cp %s/reg_using_initiation_matrix/register.f%03i.dof6.dat.mincost %s/register.f%03i.dof6.dat.mincost',...
                               matrices_dir,i,matrices_dir,i));
                        system(sprintf('cp %s/reg_using_initiation_matrix/register.f%03i.dof6.dat.param %s/register.f%03i.dof6.dat.param',...
                               matrices_dir,i,matrices_dir,i));
                        system(sprintf('cp %s/reg_using_initiation_matrix/register.f%03i.dof6.dat.sum %s/register.f%03i.dof6.dat.sum',...
                               matrices_dir,i,matrices_dir,i));  
                     end
              end

              clear q_factor_reg q_factor q_dummy C I ans 

           else
              Error_Message_01 = sprintf('There is a problem that needs to be solved before the data analysis can continue.');
              Error_Message_02 = sprintf('Something with the registration files in %s is wrong.',matrices_dir);
              Error_Message_03 = sprintf('At least one of the files in the first registration iteration has not been written.')
              disp(Error_Message_01)
              disp(Error_Message_02)
              disp(Error_Message_03)
              pause
           end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%           
% Transformation from Volume to surface
           
		   for depth_index = 1:length(cortical_depths_for_sampling)
		          
		       cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
			         
                       frame_mod_dir = sprintf('%s/03_frames_mod_%s_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
		       
               if exist(sprintf('%s',frame_mod_dir)) == 0
                  system(sprintf('mkdir %s',frame_mod_dir));
               end 
		   
               for i = 1:frame_number 
               
                   frame_focus = sprintf('f%03i.nii',i);
                   functional_reg = sprintf('%s/register.f%03i.dof6.dat',matrices_dir,i); 
               
                   if exist(sprintf('%s/%s',frame_mod_dir,frame_focus)) == 0
                      system(sprintf('mri_vol2surf --mov %s/%s --reg %s --interp nearest --projdist %f --hemi lh --o %s/%s --noreshape --cortex',...
                         functional_frame_dir,frame_focus,functional_reg,...
						 cortical_depths_for_sampling(depth_index),...
						 frame_mod_dir,frame_focus));
                   end
			   end
		   end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
%% FS-FAST preprocessing: Correction of registration if necessary.

           cd(sprintf('%s',maindir));
           if exist(sprintf('./%s_orig/bold/001/register.dof6.dat.mincost',finger)) ~= 0
              q_dummy = dlmread(sprintf('./%s_orig/bold/001/register.dof6.dat.mincost',finger));
              q_dummy = q_dummy(1);
              
              for i = 1:frame_number
                  q_dummy     = dlmread(sprintf('%s/register.f%03i.dof6.dat.mincost',matrices_dir,i));
                  q_factor(i) = q_dummy(1);  
              end
              
              if q_factor(middle_frame) < q_dummy
                 system(sprintf('cp %s/register.f%03i.dof6.dat ./%s_orig/bold/001/register.dof6.dat',...
                            matrices_dir,middle_frame,finger));
                 system(sprintf('cp %s/register.f%03i.dof6.dat.log ./%s_orig/bold/001/register.dof6.dat.log',...
                            matrices_dir,middle_frame,finger));
                 system(sprintf('cp %s/register.f%03i.dof6.dat.mincost ./%s_orig/bold/001/register.dof6.dat.mincost',...
                            matrices_dir,middle_frame,finger));
                 system(sprintf('cp %s/register.f%03i.dof6.dat.param ./%s_orig/bold/001/register.dof6.dat.param',...
                            matrices_dir,middle_frame,finger));
                 system(sprintf('cp %s/register.f%03i.dof6.dat.sum ./%s_orig/bold/001/register.dof6.dat.sum',...
                            matrices_dir,middle_frame,finger));
                  system(sprintf('preproc-sess -s ./%s_orig -fsd bold -nostc -surface self lh -fwhm 0 -per-run -nosmooth -noreg -regfile ./%s_orig/bold/001/register.dof6.dat -force >> preproc_log.dat',finger,finger));
              end  
           end

%% Generation of directory structure for BBR-Fast-Evaluation
           if exist(sprintf('%s/%s/bold/001/masks',maindir,finger)) == 0
              system(sprintf('mkdir %s/%s/bold/001/masks',maindir,finger))
           end

           source = sprintf('%s/%s_orig/bold/001/masks/brain.self.lh.nii.gz',maindir,finger);
           destination = sprintf('%s/%s/bold/001/masks/brain.self.lh.nii.gz',maindir,finger);
           if exist(destination) == 0
              copyfile(source,destination)
           end   

           source = sprintf('%s/%s_orig/bold/001/global.meanval.dat',maindir,finger);
           destination = sprintf('%s/%s/bold/001/global.meanval.dat',maindir,finger);
           if exist(destination) == 0
              copyfile(source,destination)
           end 

           if exist(sprintf('%s/%s_orig/bold/fmcpr.mcdat.png',maindir,finger)) == 0
              cd(sprintf('%s',maindir));
              system(sprintf('plot-twf-sess   -s ./%s_orig  -fsd bold -mc',finger)) 
           end

%            check_file = sprintf('%s/%s/bold/001/bbr.mcdat',maindir,finger);
%            if exist(check_file) == 0
           
           register_dat_param_ref_frame = dlmread(sprintf('%s/register.f%03i.dof6.dat.param',matrices_dir,middle_frame),'');
           trans_ref_frame              = register_dat_param_ref_frame(1:3);
           angles_ref_frame             = register_dat_param_ref_frame(4:6);

           
              for idx_motion = 1:frame_number

                  register_dat_param = dlmread(sprintf('%s/register.f%03i.dof6.dat.param',matrices_dir,idx_motion),'');
                  mc_trans  = register_dat_param(1:3)-trans_ref_frame;
                  mc_angles = register_dat_param(4:6)-angles_ref_frame;

                  % ambflag=1 indicates some ambiguity (eb, cos(beta)=1)
                  translation = sqrt(mc_trans(1)^2+mc_trans(2)^2+mc_trans(3)^2);
    
                  fmcpr_mcdat_bbr(idx_motion,:) = [idx_motion-1 mc_trans(1) mc_trans(2) mc_trans(3) mc_angles(1) mc_angles(2) mc_angles(3) 0 0 translation];
              end
              dlmwrite(sprintf('%s/%s/bold/001/bbr.mcdat',maindir,finger),fmcpr_mcdat_bbr,' ')
%            end

%            check_file = sprintf('%s/%s/bold/001/mcprextreg',maindir,finger);
%            if exist(check_file) == 0
                system(sprintf('mcdat2mcextreg --i %s/%s/bold/001/bbr.mcdat --o %s/%s/bold/001/mcprextreg',maindir,finger,maindir,finger))
%            end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

              % create overview concerning q-values and translations due to 
              % motion
              close all
              for i = 1:frame_number
                  q_dummy     = dlmread(sprintf('%s/register.f%03i.dof6.dat.mincost',matrices_dir,i));
                  q_factor(i) = q_dummy(1);  
              end
              delete(sprintf('%s/q_factors.mat',matrices_dir))
              save(sprintf('%s/q_factors.mat',matrices_dir),'q_factor')
           
              close all
              subplot(2,1,1)
                     plot(q_factor,'.-');
                         xlabel('frame no.')
                         ylabel('q-factor')
              subplot(2,1,2)
                     fmcpr_mcdat_bbr = dlmread(sprintf('%s/%s/bold/001/bbr.mcdat',maindir,finger),' ');
                     plot(fmcpr_mcdat_bbr(:,10),'.-')
                         xlabel('time point')
                         ylabel('translation')
              delete(sprintf('%s/q_factors.fig',matrices_dir))
              saveas(gcf,sprintf('%s/q_factors.fig',matrices_dir))  
              close all
           
              clear ans h q_dummy      
              
end      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%% Evaluation FS-Fast and Greifswald-FAST at the various levels

cd(sprintf('%s',maindir));
system('mkanalysis-sess -fsd bold -surface self lh -fwhm 0 -event-related -paradigm sensory.par -nconditions 1 -spmhrf 0 -TR 1 -refeventdur 10 -nskip 5 -polyfit 2 -analysis stim.sensory.lh -mcextreg -delay 0 -per-run -force')
system('mkcontrast-sess -analysis  stim.sensory.lh -contrast stim01-v-base -a 1')



delete('dummy.tcl')
    fid=fopen('dummy.tcl','w');
        fprintf(fid,'%s\n','labl_remove_all'); 
        fprintf(fid,'%s\n','set truncphaseflag 1'); 
        fprintf(fid,'%s\n','set colscalebarflag 1'); 
        fprintf(fid,'%s\n','labl_remove_all'); 
%         fprintf(fid,'%s\n','label_to_stat 0'); 
%         fprintf(fid,'%s\n','set fthresh 3 '); 
%         fprintf(fid,'%s\n','set fmid 3'); 
%         fprintf(fid,'%s\n','labl_set_color 0 255 255 255');
%         fprintf(fid,'%s\n','set val ./sig_weighted_BA3b.nii'); 
%         fprintf(fid,'%s\n','sclv_write_dotw 0'); 
        fprintf(fid,'%s\n',sprintf('labl_load %s/%s/label/%s',subjects_dir,subject,finger_label)); 
        fprintf(fid,'%s\n','labl_select -1');    
        fprintf(fid,'%s\n','set labelstyle 1');         
        fprintf(fid,'%s\n','labl_set_color 0 255 255 255');
        fprintf(fid,'%s\n','labl_print_list');   
%         fprintf(fid,'%s\n','set truncphaseflag 1'); 
%         fprintf(fid,'%s\n','set colscalebarflag 1'); 
%         fprintf(fid,'%s\n','translate_brain_x   0'); 
%         fprintf(fid,'%s\n','translate_brain_y -40'); 
%         fprintf(fid,'%s\n','scale_brain 4'); 
        fprintf(fid,'%s\n','redraw'); 
%         fprintf(fid,'%s\n','exit');
    fclose(fid);


for depth_index = 1:length(cortical_depths_for_sampling)
	
	cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/03_frames_mod_%s_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
	
    system(sprintf('mri_concat --i %s/f*.nii --o %s/fmcpr.sm0.self.lh.nii.gz',...
           frame_mod_dir,frame_mod_dir))
    
    system(sprintf('mri_convert -tr 1000 %s/fmcpr.sm0.self.lh.nii.gz %s/fmcpr.sm0.self.lh.nii.gz',...
           frame_mod_dir,frame_mod_dir))
    
    system(sprintf('mri_convert -tr 1000 %s/fmcpr.sm0.self.lh.nii.gz %s/fmcpr.sm0.self.lh.mgz',...
           frame_mod_dir,frame_mod_dir))
       
       
    source = sprintf('%s/%s',maindir,finger);
    destination = sprintf('%s/%s_depth_%05i_microns',maindir,finger,cortical_depths_for_sampling_reduced);
    if exist(destination) == 0
       copyfile(source,destination)
    end 
    
    source = sprintf('%s/fmcpr.sm0.self.lh.nii.gz',frame_mod_dir);
    destination = sprintf('%s/%s_depth_%05i_microns/bold/001/fmcpr.sm0.self.lh.nii.gz',maindir,finger,cortical_depths_for_sampling_reduced);
    copyfile(source,destination)
    
    system(sprintf('selxavg3-sess -s ./%s_depth_%05i_microns -analysis stim.sensory.lh -no-preproc -force',finger,cortical_depths_for_sampling_reduced))
    if display_cortical_maps == 1
%       system(sprintf('tksurfer-sess -s ./%s_depth_%05i_microns -analysis stim.sensory.lh -c stim01-v-base -fthresh 3 -tcl dummy.tcl',finger,cortical_depths_for_sampling_reduced))
       system(sprintf('tksurfer %s lh inflated -overlay %s/%s_depth_%05i_microns/bold/stim.sensory.lh/stim01-v-base/sig.nii.gz -annot aparc pial -fminmax 3 4 -tcl dummy.tcl',subject_name,maindir,finger,cortical_depths_for_sampling_reduced))
    end
end

system(sprintf('selxavg3-sess -s ./%s_orig -analysis stim.sensory.lh -no-preproc -force',finger))
if display_cortical_maps == 1
%   system(sprintf('tksurfer-sess -s ./%s_orig -analysis stim.sensory.lh -c stim01-v-base -fthresh 3 -tcl dummy.tcl -fminmax 3 4',finger))
   system(sprintf('tksurfer %s lh inflated -overlay %s/%s_orig/bold/stim.sensory.lh/stim01-v-base/sig.nii.gz -annot aparc pial -fminmax 3 4 -tcl dummy.tcl',subject_name,maindir,finger))
end

delete('dummy.tcl')

cd(script_dir);


%% FDR corrected display contrast 1

            % cd(sprintf('%s',maindir));
            % sig_nii_path = 'bold/stim.sensory.lh/stim01-v-base/sig.nii.gz';
            %  
            % 
            % system(sprintf('mri_surfcluster --in ./%s_orig/%s --fdr 0.05 --thmax infinity --sign pos --subject %s --hemi %s --sum %s --clabel %s',...
            %        finger,sig_nii_path,subject,'lh',sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)))
            % 
            % system(sprintf('cat %s_surfcluster_BA3b_finger_region_fdr.txt',finger))   
            %         A                  = importdata(sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),' ',36); 
            %         data               = A.data;
            %         vertex_index_01(j) = data(1,3);
            %         peak_01(j)         = data(1,2);
            %         Size_01(j)         = data(1,4);
            % system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim01-v-base -fthresh 3 -tcl display_right_hand.tcl',finger));

%% FDR corrected display contrast 2

            % cd(sprintf('%s',maindir));
            % sig_nii_path = 'bold/stim.sensory.lh/stim02-v-base/sig.nii.gz';
            %  
            % 
            % system(sprintf('mri_surfcluster --in ./%s_orig/%s --fdr 0.05 --thmax infinity --sign pos --subject %s --hemi %s --sum %s --clabel %s',...
            %        finger,sig_nii_path,subject,'lh',sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)))
            % 
            %system(sprintf('cat %s_surfcluster_BA3b_finger_region_fdr.txt',finger))   
            %         A                  = importdata(sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),' ',36); 
            %         data               = A.data;
            %         vertex_index_02(j) = data(1,3);
            %         peak_02(j)         = data(1,2);
            %         Size_02(j)         = data(1,4);
            % system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim02-v-base -fthresh 3 -tcl display_right_hand.tcl',finger));

        
  

% save(mfilename)
