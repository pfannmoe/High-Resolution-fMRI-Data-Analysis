%%
clear all; clc;

subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; %exactly the same string as in file A_...

raw_data_list = {'Name_of_Folder_with_EPI_DICOMS_of_Subject_01'
	             'Name_of_Folder_with_EPI_DICOMS_of_Subject_02'
				 'Name_of_Folder_with_EPI_DICOMS_of_Subject_03'};%exactly the same string as in file A_...

raw_data_file = char(raw_data_list(1));
script_dir    = pwd;
subject_name  = char(subject_list(1));

cd(sprintf('%s/%s',script_dir,subject_name));
maindir                     = pwd;

finger                       = 'NAME OF EXPERIMENT (abbreviation like D1_right_hand)'; %exactly the same string as in file A_...
anatomy_slice = 207;%"please_set_an_integer_value";

raw_data                    = sprintf('%s/RawData/%s',sprintf('%s/%s',script_dir,subject_name),raw_data_file);
folder_listing               = dir([raw_data '/*.dcm']);
frame_number                 = size(folder_listing,1)
%%

for i = 1:frame_number 

	system(sprintf('tkregister --mov %s/workdir/01_frames_%s/f%03i.nii --reg %s/workdir/02_matrices_%s/register.f%03i.dof6.dat --plane ax --slice %i --surfs',...
           maindir,finger,i,maindir,finger,i,anatomy_slice))

end