%%
clear all; clc;

vertex = ;   %As shown in tksurfer so NOT matlab convetion.

%% Load the optimized time series for analysis purposes.

script_dir    = pwd;
subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; %exactly the same string as in file A_...
subjects_dir  = getenv('SUBJECTS_DIR');

for idx = 1:length(subject_list)
    
    subject_name = char(subject_list(idx));
    subject      = subject_name;
    cd(sprintf('%s/%s',script_dir,subject_name));
    maindir  = pwd;
    workdir  = sprintf('%s/workdir',maindir);
    load_dir = sprintf('%s/08_optimized_time_series',workdir);
    
    if exist(sprintf('%s',load_dir)) ~= 0
        
        if exist(sprintf('%s/optimized_time_series.mat',load_dir)) ~= 0
            load(sprintf('%s/optimized_time_series.mat',load_dir))
            %% Display fractions at certain vertex
            % largest peak in BA3b fingertip label
            clf('reset')
            subplot(1,3,1)
            [C,I] = min(abs(finger_label_vertices_matlab-vertex));
            plot(wm_nearest_optimized(I,:))
            xlabel('frame number ~ time')
            title('WM fractions')
            subplot(1,3,2)
            plot(gm_nearest_optimized(I,:))
            xlabel('frame number ~ time')
            title('GM fractions')
            subplot(1,3,3)
            plot(csf_nearest_optimized(I,:))
            xlabel('frame number ~ time')
            title('CSF fractions')
            clear C I
        else
            disp('The data are not in folder 08_...')
        end
        
    else
        disp('Folder 08_... has not yet been created.')
    end
    
    pause
    
end