%%
clear all; clc;
%%   
script_dir    = pwd;
subjects_dir  = getenv('SUBJECTS_DIR');
finger_label  = 'lh.BA3b_Weibull_3p5sigma.label';

subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; %exactly the same string as in file A_...

raw_data_list = {'Name_of_Folder_with_EPI_DICOMS_of_Subject_01'
	             'Name_of_Folder_with_EPI_DICOMS_of_Subject_02'
				 'Name_of_Folder_with_EPI_DICOMS_of_Subject_03'};




for j = 1:length(subject_list)
    
    subject_name = char(subject_list(j));
    
           cd(sprintf('%s/%s',script_dir,subject_name));
           maindir                     = pwd;
           raw_data_file      = char(raw_data_list(j));
           raw_data                    = sprintf('%s/RawData/%s',maindir,raw_data_file);
           subject                     = subject_name;

%%
           finger                      = 'NAME OF EXPERIMENT (abbreviation like D1_right_hand)';
           workdir                     = sprintf('%s/workdir',maindir)
           frame_dir                   = 'frames';
           finger                      = sprintf('%s_optimized',finger);

%% 
	
		
            cd(sprintf('%s',maindir));
%             system('mkanalysis-sess -fsd bold -surface self lh -fwhm 0 -event-related -paradigm sensory.par -nconditions 1 -spmhrf 0 -TR 1 -refeventdur 10 -nskip 10 -polyfit 2 -analysis stim.sensory.lh -mcextreg -delay 0 -per-run -force')
            system('mkanalysis-sess -fsd bold -surface self lh -fwhm 0 -event-related -paradigm sensory.par -nconditions 1 -spmhrf 0 -TR 1 -refeventdur 1 -nskip 1 -polyfit 2 -analysis stim.sensory.lh -mcextreg -delay 0 -per-run -force')
            system('mkcontrast-sess -analysis  stim.sensory.lh -contrast stim01-v-base -a 1')
            
            system(sprintf('selxavg3-sess -s ./%s -analysis stim.sensory.lh -no-preproc -force',finger))
            
            
            
            


delete('dummy.tcl')
    fid=fopen('dummy.tcl','w');
        fprintf(fid,'%s\n','labl_remove_all'); 
%         fprintf(fid,'%s\n','set truncphaseflag 1'); 
        fprintf(fid,'%s\n','set colscalebarflag 1'); 
        fprintf(fid,'%s\n','labl_remove_all'); 
%         fprintf(fid,'%s\n','label_to_stat 0'); 
%         fprintf(fid,'%s\n','set fthresh 3 '); 
%         fprintf(fid,'%s\n','set fmid 3'); 
%         fprintf(fid,'%s\n','labl_set_color 0 255 255 255');
%         fprintf(fid,'%s\n','set val ./sig_weighted_BA3b.nii'); 
%         fprintf(fid,'%s\n','sclv_write_dotw 0'); 
        fprintf(fid,'%s\n',sprintf('labl_load %s/%s/label/%s',subjects_dir,subject,finger_label)); 
        fprintf(fid,'%s\n','labl_select -1');    
        fprintf(fid,'%s\n','set labelstyle 1');         
        fprintf(fid,'%s\n','labl_set_color 0 255 255 255');
        fprintf(fid,'%s\n','labl_print_list');   
%         fprintf(fid,'%s\n','set truncphaseflag 1'); 
%         fprintf(fid,'%s\n','set colscalebarflag 1'); 
%         fprintf(fid,'%s\n','translate_brain_x   0'); 
%         fprintf(fid,'%s\n','translate_brain_y -40'); 
%         fprintf(fid,'%s\n','scale_brain 4'); 
        fprintf(fid,'%s\n','redraw'); 
%         fprintf(fid,'%s\n','exit');
    fclose(fid);
% 
%             system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim01-v-base -fthresh 3 -tcl dummy.tcl',finger))
% 	system(sprintf('tksurfer repro_Kobrow lh inflated -overlay %s/%s/bold/stim.sensory.lh/stim01-v-base/sig.nii.gz -annot aparc pial -fminmax 3 4',maindir,finger))
    system(sprintf('tksurfer %s lh inflated -overlay %s/%s/bold/stim.sensory.lh/stim01-v-base/sig.nii.gz -annot aparc pial -fminmax 3 4 -tcl dummy.tcl',subject_name,maindir,finger))
    delete('dummy.tcl')
%             system(sprintf('tksurfer-sess -s ./%s_orig -analysis stim.sensory.lh -c stim01-v-base -fthresh 3',finger))
%             system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim02-v-base -fthresh 3 -tcl dummy.tcl',finger))
%             system(sprintf('tksurfer-sess -s ./%s_orig -analysis stim.sensory.lh -c stim02-v-base -fthresh 3',finger))
            
            
%             system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim01-v-base -fthresh 3',finger))
%             system(sprintf('tksurfer-sess -s ./%s_orig -analysis stim.sensory.lh -c stim01-v-base -fthresh 3',finger))
%             system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim02-v-base -fthresh 3',finger))
%             system(sprintf('tksurfer-sess -s ./%s_orig -analysis stim.sensory.lh -c stim02-v-base -fthresh 3',finger))
%% FDR corrected display contrast 1

            % cd(sprintf('%s',maindir));
            % sig_nii_path = 'bold/stim.sensory.lh/stim01-v-base/sig.nii.gz';
            %  
            % 
            % system(sprintf('mri_surfcluster --in ./%s_orig/%s --fdr 0.05 --thmax infinity --sign pos --subject %s --hemi %s --sum %s --clabel %s',...
            %        finger,sig_nii_path,subject,'lh',sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)))
            % 
            % system(sprintf('cat %s_surfcluster_BA3b_finger_region_fdr.txt',finger))   
            %         A                  = importdata(sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),' ',36); 
            %         data               = A.data;
            %         vertex_index_01(j) = data(1,3);
            %         peak_01(j)         = data(1,2);
            %         Size_01(j)         = data(1,4);
            % system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim01-v-base -fthresh 3 -tcl display_right_hand.tcl',finger));

%% FDR corrected display contrast 2

            % cd(sprintf('%s',maindir));
            % sig_nii_path = 'bold/stim.sensory.lh/stim02-v-base/sig.nii.gz';
            %  
            % 
            % system(sprintf('mri_surfcluster --in ./%s_orig/%s --fdr 0.05 --thmax infinity --sign pos --subject %s --hemi %s --sum %s --clabel %s',...
            %        finger,sig_nii_path,subject,'lh',sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)))
            % 
            %system(sprintf('cat %s_surfcluster_BA3b_finger_region_fdr.txt',finger))   
            %         A                  = importdata(sprintf('%s_surfcluster_BA3b_finger_region_fdr.txt',finger),' ',36); 
            %         data               = A.data;
            %         vertex_index_02(j) = data(1,3);
            %         peak_02(j)         = data(1,2);
            %         Size_02(j)         = data(1,4);
            % system(sprintf('tksurfer-sess -s ./%s -analysis stim.sensory.lh -c stim02-v-base -fthresh 3 -tcl display_right_hand.tcl',finger));

        
  
end
% save(mfilename)

cd(script_dir);
