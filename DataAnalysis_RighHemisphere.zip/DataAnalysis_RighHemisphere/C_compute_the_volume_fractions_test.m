%%
clear all; clc;
%%   
script_dir                   = pwd;
subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; %exactly the same string as in file A_...

raw_data_list = {'Name_of_Folder_with_EPI_DICOMS_of_Subject_01'
	             'Name_of_Folder_with_EPI_DICOMS_of_Subject_02'
				 'Name_of_Folder_with_EPI_DICOMS_of_Subject_03'};%exactly the same string as in file A_...

finger        = 'NAME OF EXPERIMENT (abbreviation like D1_left_hand)'; %exactly the same string as in file A_...

%%
cd(sprintf('%s',script_dir))

for subject_index = 1:length(subject_list)
    
    subject_name   = char(subject_list(subject_index));
    raw_data_file  = char(raw_data_list(subject_index));
	               
    raw_data       = sprintf('%s/%s/RawData/%s',script_dir,subject_name,raw_data_file);
    folder_listing = dir([raw_data '/*.dcm']);
    frame_number   = size(folder_listing,1)
    
    cd(sprintf('%s/%s',script_dir,subject_name));
    maindir        = pwd;
    workdir        = sprintf('%s/workdir',maindir);
    
    if exist(sprintf('%s/04_fractions_%s',workdir,finger)) == 0
       mkdir(sprintf('%s/04_fractions_%s',workdir,finger));
    end
    
    tmp_folder = sprintf('%s/04_fractions_%s/tmp_delete',workdir,finger);
    
    for index = 1:frame_number
    
        if exist(tmp_folder) ~= 0
           rmdir(tmp_folder,'s')
        end
        
        mkdir(tmp_folder) 
        
        reg_file              = sprintf('%s/02_matrices_%s/register.f%03i.dof6.dat',workdir,finger,index);
        input_volume_original = sprintf('%s/%s/RawData/%s/%s',script_dir,subject_name,raw_data_file,folder_listing(index).name);
% .nii possible for outputstem???????        
        output_stem  = sprintf('%s/04_fractions_%s/IM-%05i',workdir,finger,index);
    
        source = input_volume_original;
        destination = tmp_folder;
        
        if exist(sprintf('%s/*-%05i.dcm',destination,index)) == 0
           copyfile(source,destination)
        end
        
        input_volume_tmp = sprintf('%s/%s',tmp_folder,folder_listing(index).name);
        
        if exist(sprintf('%s.cortex.mgz',output_stem)) == 0
           sprintf('mri_compute_volume_fractions %s %s %s',reg_file,input_volume_tmp,output_stem)
%          pause
           system(sprintf('mri_compute_volume_fractions %s %s %s',reg_file,input_volume_tmp,output_stem))
        end
        
        if exist(tmp_folder) ~= 0
           rmdir(tmp_folder,'s')
        end
        
    end
end

if exist(tmp_folder) ~= 0
   rmdir(tmp_folder,'s')
end

cd(script_dir);