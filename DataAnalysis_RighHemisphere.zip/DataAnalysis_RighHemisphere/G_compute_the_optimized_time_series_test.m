%%
clear all; clc;
%%   
script_dir    = pwd;
subjects_dir  = getenv('SUBJECTS_DIR');
finger_label  = 'rh.BA3b_Weibull_3p5sigma.label';

subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; %exactly the same string as in file A_...


finger        = 'NAME OF EXPERIMENT (abbreviation like D1_left_hand)'; %exactly the same string as in file A_...	   

cortical_depths_for_sampling = [0 0.3 0.6]; %distance projection along normal


for j = 1:length(subject_list)
    
    subject_name = char(subject_list(j));
    subject      = subject_name;
    cd(sprintf('%s/%s',script_dir,subject_name));
    maindir      = pwd;
    workdir      = sprintf('%s/workdir',maindir)
    fractions_data    = sprintf('%s/04_fractions_%s',workdir,finger);
    filename          = 'IM-*.cortex.mgz';
    path_and_filename = sprintf('%s/%s',fractions_data,filename);
    listing           = dir(path_and_filename);
    frame_number  = length(listing);
    
    if  exist(sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label)) == 0
        system(sprintf('mri_label2label --srclabel %s/fsaverage/label/%s --srcsubject fsaverage --trglabel %s --trgsubject %s --regmethod surface --hemi rh',subjects_dir,finger_label,finger_label,subject));
    end 
    
    finger_label_matrix          = dlmread(sprintf('%s/%s/label/%s',subjects_dir,subject,finger_label),'',2,0);
    finger_label_vertices        = finger_label_matrix(:,1);
    finger_label_vertices_matlab = finger_label_vertices + 1;
    
    %% Gray Matter Fractions
    
    depth_index                          = 3;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/05_fractions_mod_%s_fractions_gm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_gm_nearest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)     
        
    depth_index                          = 2;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/05_fractions_mod_%s_fractions_gm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_gm_nearest_low M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)   
        
    depth_index                          = 1;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/05_fractions_mod_%s_fractions_gm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_gm_nearest_lowest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)  
        
%     sizes_gm = size(vol_gm_nearest_lowest);    
%     gm_optimized = zeros(sizes_gm);    
    %% CSF Fractions
    
    depth_index                          = 3;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/06_fractions_mod_%s_fractions_csf_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_csf_nearest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)     
       
    depth_index                          = 2;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/06_fractions_mod_%s_fractions_csf_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_csf_nearest_low M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)   
        
    depth_index                          = 1;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/06_fractions_mod_%s_fractions_csf_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_csf_nearest_lowest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)  
        
%     sizes_csf = size(vol_csf_nearest_lowest);    
%     csf_optimized = zeros(sizes_csf);  

    %% WM Fractions
    
    depth_index                          = 3;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/07_fractions_mod_%s_fractions_wm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_wm_nearest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)     
       
    depth_index                          = 2;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/07_fractions_mod_%s_fractions_wm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_wm_nearest_low M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)   
        
    depth_index                          = 1;
    cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/07_fractions_mod_%s_fractions_wm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fractions.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [vol_wm_nearest_lowest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)  
        
%     sizes_wm = size(vol_wm_nearest_lowest);    
%     wm_optimized = zeros(sizes_wm); 
    %% functional time series
    depth_index                          = 3;
	cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/03_frames_mod_%s_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fmcpr.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [fmcpr_nearest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)     
        
    depth_index                          = 2;
	cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/03_frames_mod_%s_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fmcpr.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [fmcpr_nearest_low M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)     

    depth_index                          = 1;
	cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    frame_mod_dir = sprintf('%s/03_frames_mod_%s_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
   
        frame_focus = sprintf('fmcpr.sm0.self.rh.mgz');
        fname = sprintf('%s/%s',frame_mod_dir,frame_focus);
        [fmcpr_nearest_lowest M] = load_mgh(fname);%,<slices>,<frames>,<headeronly>)    
        
    sizes_fmcpr = size(fmcpr_nearest);
	
	clear fmcpr_nearest_optimized gm_nearest_optimized csf_nearest_optimized wm_nearest_optimized
    fmcpr_nearest_optimized = zeros(sizes_fmcpr);
    gm_nearest_optimized = zeros(length(finger_label_vertices_matlab),frame_number);
	csf_nearest_optimized = zeros(length(finger_label_vertices_matlab),frame_number);
	
    % This is restricted to the label!
    for count_index = 1:length(finger_label_vertices_matlab)
        
        gm_nearest               = vol_gm_nearest(finger_label_vertices_matlab(count_index),:,:,:);
        gm_nearest_column        = reshape(gm_nearest,frame_number,1);
        
        gm_nearest_low           = vol_gm_nearest_low(finger_label_vertices_matlab(count_index),:,:,:);
        gm_nearest_low_column    = reshape(gm_nearest_low,frame_number,1);
        
        gm_nearest_lowest        = vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),:,:,:);
        gm_nearest_lowest_column = reshape(gm_nearest_lowest,frame_number,1);
        
        csf_nearest               = vol_csf_nearest(finger_label_vertices_matlab(count_index),:,:,:);
        csf_nearest_column        = reshape(csf_nearest,frame_number,1);
        
        csf_nearest_low           = vol_csf_nearest_low(finger_label_vertices_matlab(count_index),:,:,:);
        csf_nearest_low_column    = reshape(csf_nearest_low,frame_number,1);
        
        csf_nearest_lowest        = vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),:,:,:);
        csf_nearest_lowest_column = reshape(csf_nearest_lowest,frame_number,1);
        
        wm_nearest               = vol_wm_nearest(finger_label_vertices_matlab(count_index),:,:,:);
        wm_nearest_column        = reshape(wm_nearest,frame_number,1);
        
        wm_nearest_low           = vol_wm_nearest_low(finger_label_vertices_matlab(count_index),:,:,:);
        wm_nearest_low_column    = reshape(wm_nearest_low,frame_number,1);
        
        wm_nearest_lowest        = vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),:,:,:);
        wm_nearest_lowest_column = reshape(wm_nearest_lowest,frame_number,1);
%%        
        for intra_index = 1:length(gm_nearest_column)
            %Quality control index to check if at least one of the
            %following procedures is executed and if not more than one is
            %executed.
            test_index = 0;
            
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If all three gm are zero
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if gm_nearest_column(intra_index) == 0 && ...
               gm_nearest_low_column(intra_index) == 0 && ...
               gm_nearest_lowest_column(intra_index) == 0 
               
               if csf_nearest_column(intra_index) <  csf_nearest_low_column(intra_index) && ...
                  csf_nearest_column(intra_index) <  csf_nearest_lowest_column(intra_index) 
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif csf_nearest_low_column(intra_index) <  csf_nearest_column(intra_index) && ...
                      csf_nearest_low_column(intra_index) <  csf_nearest_lowest_column(intra_index) 
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif csf_nearest_lowest_column(intra_index) <  csf_nearest_column(intra_index) && ...
                      csf_nearest_lowest_column(intra_index) <  csf_nearest_low_column(intra_index) 
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif csf_nearest_column(intra_index) >  csf_nearest_low_column(intra_index) && ...
                      csf_nearest_column(intra_index) >  csf_nearest_lowest_column(intra_index) && ...
                      csf_nearest_low_column(intra_index) == csf_nearest_lowest_column(intra_index)
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif csf_nearest_low_column(intra_index) >  csf_nearest_column(intra_index) && ...
                      csf_nearest_low_column(intra_index) >  csf_nearest_lowest_column(intra_index) && ...
                      csf_nearest_column(intra_index) == csf_nearest_lowest_column(intra_index)
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif csf_nearest_lowest_column(intra_index) >  csf_nearest_column(intra_index) && ...
                      csf_nearest_lowest_column(intra_index) >  csf_nearest_low_column(intra_index) && ...
                      csf_nearest_column(intra_index) == csf_nearest_low_column(intra_index)
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif csf_nearest_lowest_column(intra_index) == csf_nearest_column(intra_index) && ...
                      csf_nearest_lowest_column(intra_index) == csf_nearest_low_column(intra_index) && ...
                      csf_nearest_column(intra_index) == csf_nearest_low_column(intra_index)
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               end   
            end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If two gm are zero
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if gm_nearest_column(intra_index) == 0 && ...
               gm_nearest_low_column(intra_index) == 0 && ...
               gm_nearest_lowest_column(intra_index) ~= 0 
                
               fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
            elseif  gm_nearest_column(intra_index) == 0 && ...
               gm_nearest_lowest_column(intra_index) == 0 && ...
               gm_nearest_low_column(intra_index) ~= 0 
                
               fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);   
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
            elseif  gm_nearest_low_column(intra_index) == 0 && ...
               gm_nearest_lowest_column(intra_index) == 0 && ...
               gm_nearest_column(intra_index) ~= 0 
                
               fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);      
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                
            end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If one gm is zero
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if gm_nearest_column(intra_index) == 0 && ...
               gm_nearest_low_column(intra_index) ~= 0 && ...
               gm_nearest_lowest_column(intra_index) ~= 0
            
               ratio01 = csf_nearest_low_column(intra_index)/gm_nearest_low_column(intra_index);
               ratio02 = csf_nearest_lowest_column(intra_index)/gm_nearest_lowest_column(intra_index);
               
               if ratio01 < ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);

                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif   ratio01 == ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
               
               else
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);  
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
               end
               
            elseif gm_nearest_low_column(intra_index) == 0 && ...
               gm_nearest_column(intra_index) ~= 0 && ...
               gm_nearest_lowest_column(intra_index) ~= 0
                
               ratio01 = csf_nearest_column(intra_index)/gm_nearest_column(intra_index);
               ratio02 = csf_nearest_lowest_column(intra_index)/gm_nearest_lowest_column(intra_index);
               
               if ratio01 < ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index); 
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif   ratio01 == ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
               
               else
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index); 
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
               end
               
            elseif gm_nearest_lowest_column(intra_index) == 0 && ...
               gm_nearest_low_column(intra_index) ~= 0 && ...
               gm_nearest_column(intra_index) ~= 0
                
               ratio01 = csf_nearest_column(intra_index)/gm_nearest_column(intra_index);
               ratio02 = csf_nearest_low_column(intra_index)/gm_nearest_low_column(intra_index);
               
               if ratio01 < ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif   ratio01 == ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
               
			   else
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index); 
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
               end
               
            end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% If no gm is zero
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            if gm_nearest_column(intra_index) ~= 0 && ...
                gm_nearest_low_column(intra_index) ~= 0 && ...    
                  gm_nearest_lowest_column(intra_index) ~= 0
                  
                  
               ratio01 = csf_nearest_column(intra_index)/gm_nearest_column(intra_index);
               ratio02 = csf_nearest_low_column(intra_index)/gm_nearest_low_column(intra_index);
               ratio03 = csf_nearest_lowest_column(intra_index)/gm_nearest_lowest_column(intra_index);
               
               if ratio01 < ratio02 && ratio01 < ratio03
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);   
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;

               elseif ratio02 < ratio01 && ratio02 < ratio03
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
               elseif ratio03 < ratio01 && ratio03 < ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                     fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index); 
                 
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif ratio01 == ratio02 && ratio01 == ratio03
                  
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif   ratio01 == ratio02 && ratio01 < ratio03
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif   ratio01 == ratio03 && ratio01 < ratio02
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_lowest(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                  
               elseif   ratio02 == ratio03 && ratio02 < ratio01
                   
                  fmcpr_nearest_optimized(finger_label_vertices_matlab(count_index),1,1,intra_index) = ...
                      fmcpr_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  gm_nearest_optimized(count_index,intra_index) = ...
                      vol_gm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  csf_nearest_optimized(count_index,intra_index) = ...
                      vol_csf_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  wm_nearest_optimized(count_index,intra_index) = ...
                      vol_wm_nearest_low(finger_label_vertices_matlab(count_index),1,1,intra_index);
                  
                  test_index = test_index+1;
                 
               end
               
            end  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  

            if test_index == 0
               sprintf('Problem!!') 
               pause
               
            elseif test_index > 1
               sprintf('Too much!!') 
               pause
            end    
            test_index = 0;
            
        end   
        
%         sprintf('total number of vertices = %i  This is vertex %i',...
%             sizes_fmcpr(1),finger_label_vertices_matlab(count_index))

    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Save the optimized time series for subsequent analysis purposes.
save_dir = sprintf('%s/08_optimized_time_series',workdir);

if exist(save_dir) == 0
   mkdir(save_dir)
elseif exist(save_dir) ~= 0
   rmdir(save_dir,'s')
   mkdir(save_dir)
end

save(sprintf('%s/optimized_time_series.mat',save_dir),...
    'finger_label_vertices_matlab','gm_nearest_optimized',...
    'csf_nearest_optimized','wm_nearest_optimized')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delete(sprintf('%s/fmcpr_optimized.sm0.self.rh.mgz',maindir));

tr = 1000;
flipangle = 76;
te = 36;
ti = 0;
mr_parms = [tr flipangle te ti];
fname = sprintf('fmcpr_optimized.sm0.self.rh.mgz');
save_mgh(fmcpr_nearest_optimized,fname, M, mr_parms);

if exist(sprintf('%s/%s_optimized',maindir,finger)) > 0
   rmdir(sprintf('%s/%s_optimized',maindir,finger),'s');
end

copyfile(sprintf('%s/%s',maindir,finger),...
     sprintf('%s/%s_optimized',maindir,finger));

if exist(sprintf('%s/%s_optimized/bold/stim.sensory.rh',maindir,finger)) > 0
   rmdir(sprintf('%s/%s_optimized/bold/stim.sensory.rh',maindir,finger),'s');
end

delete(sprintf('%s/%s_optimized/bold/001/fmcpr.sm0.self.rh.nii.gz',maindir,finger));

% copyfile(sprintf('%s/rechte_hand_D1_A_nearest_optimized/',maindir),...
% 	     sprintf('%s/rechte_hand_D1_A_nearest_opti_smooth2mm/',maindir));
% 
% copyfile(sprintf('%s/rechte_hand_D1_A_nearest_optimized/',maindir),...
% 	     sprintf('%s/rechte_hand_D1_A_nearest_opti_smooth4mm/',maindir));
	 
copyfile(sprintf('%s/fmcpr_optimized.sm0.self.rh.mgz',maindir),...
     sprintf('%s/%s_optimized/bold/001/fmcpr.sm0.self.rh.mgz',maindir,finger));

% system(sprintf('mri_surf2surf --hemi rh --s %s --sval %s/fmcpr_optimized.sm0.self.rh.mgz --fwhm 4 --label-trg rh.BA3b_Weibull_sulcus_4sigma_10dilated.label --tval %s/rechte_hand_D1_A_nearest_opti_smooth4mm/bold/001/fmcpr.sm0.self.rh.nii.gz',subject,maindir,maindir))
% system(sprintf('mri_surf2surf --hemi rh --s %s --sval %s/fmcpr_optimized.sm0.self.rh.mgz --fwhm 2 --label-trg rh.BA3b_Weibull_sulcus_4sigma_10dilated.label --tval %s/rechte_hand_D1_A_nearest_opti_smooth2mm/bold/001/fmcpr.sm0.self.rh.nii.gz',subject,maindir,maindir))
 
delete(sprintf('%s/fmcpr_optimized.sm0.self.rh.mgz',maindir));

subplot(3,1,1)
       hist(gm_nearest_optimized(:),100)
       title('Gray Matter in optimized evaluation.')
       mean_gm   = mean(gm_nearest_optimized(:))
       median_gm = median(gm_nearest_optimized(:))
       gm_zero   = length(find(gm_nearest_optimized(:)==0))/length(gm_nearest_optimized(:))
       gm_0p01   = length(find(gm_nearest_optimized(:)<=0.01))/length(gm_nearest_optimized(:))
       gm_0p1    = length(find(gm_nearest_optimized(:)<=0.1))/length(gm_nearest_optimized(:))
       
subplot(3,1,2)    
       hist(csf_nearest_optimized(:),100)
       title('Total CSF (Pial) in optimized evaluation.')
       mean_csf   = mean(csf_nearest_optimized(:))
       median_csf = median(csf_nearest_optimized(:))
       csf_zero   = length(find(csf_nearest_optimized(:)==0))/length(csf_nearest_optimized(:))
       csf_0p01   = length(find(csf_nearest_optimized(:)<=0.01))/length(csf_nearest_optimized(:))
       csf_0p1    = length(find(csf_nearest_optimized(:)<=0.1))/length(csf_nearest_optimized(:))
       
subplot(3,1,3)   
       csf_non_zero = csf_nearest_optimized(find(csf_nearest_optimized(:)>0));
       hist(csf_non_zero,100)
       title('Non-Zero CSF (Pial) in optimized evaluation.')
       csf_non_zero_mean = mean(csf_non_zero)
       csf_non_zero_median = median(csf_non_zero)
       
clear time_series_pv_effects      

for index = 1:length(csf_nearest_optimized(:,1))   
        
    time_series_pv_effects(index) = ...
    length(find(csf_nearest_optimized(index,:)>0))/length(csf_nearest_optimized(index,:));
    
end

number_of_critical_time_series          = length(find(time_series_pv_effects > 0.1));
vertices_of_critical_time_series_matlab = finger_label_vertices_matlab(find(time_series_pv_effects > 0.1));
vertices_of_critical_time_series        = finger_label_vertices(find(time_series_pv_effects > 0.1));
fraction_of_critical_time_series        = number_of_critical_time_series/length(time_series_pv_effects)




    
end 

cd(script_dir);	
	
% fname = sprintf('gm_optimized.sm0.self.rh.mgz');
% save_mgh(gm_nearest_optimized,fname, M, mr_parms);
% [gm_vol M] = load_mgh(fname);

%         fractions_4D_at_vertex        = vol
%         fractions_4D_at_vertex_column = reshape(fractions_4D_at_vertex,frame_number,1);
% 
%         larger_0p1(count_index) =% system(sprintf('mri_surf2surf --hemi rh --s %s --sval %s/fmcpr_optimized.sm0.self.rh.mgz --fwhm 4 --label-trg rh.BA3b_Weibull_sulcus_4sigma_10dilated.label --tval %s/rechte_hand_D1_A_nearest_opti_smooth4mm/bold/001/fmcpr.sm0.self.rh.nii.gz',subject,maindir,maindir))
% system(sprintf('mri_surf2surf --hemi rh --s %s --sval %s/fmcpr_optimized.sm0.self.rh.mgz --fwhm 2 --label-trg rh.BA3b_Weibull_sulcus_4sigma_10dilated.label --tval %s/rechte_hand_D1_A_nearest_opti_smooth2mm/bold/001/fmcpr.sm0.self.rh.nii.gz',subject,maindir,maindir))
 ...
%         length(find(fractions_4D_at_vertex_column>0.1))/length(fractions_4D_at_vertex_column);
%     
%         larger_0(count_index) = ...
%         length(find(fractions_4D_at_vertex_column>0))/length(fractions_4D_at_vertex_column);
%     end
%     
%     
%     plot(B,'.')
%         subplot(2,1,1)
%                hist(larger_0p1,100)
%     
%         subplot(2,1,2)
%                vol_label = vol(finger_label_vertices_matlab);
%                hist(vol_label,100)
%                pv_median = median(vol_label)
%                pv_iqr    = iqr(vol_label)
%     pause
%         mean_fraction(count_index) = mean(fractions_4D_at_vertex_column);
%         std_fraction(count_index) = std(fractions_4D_at_vertex_column);
%         median_fraction(count_index) = median(fractions_4D_at_vertex_column);
%         iqr_fraction(count_index) = iqr(fractions_4D_at_vertex_column);
%         
%         time_series_in_label(count_index,:) = fractions_4D_at_vertex_column';
%     end
%     
%     median_larger_0p1 = median(larger_0p1)
%     iqr_larger_0p1    = iqr(larger_0p1)
%     upper_limit       = median_larger_0p1+iqr_larger_0p1
%     
%     larger_0p1_vertices = length(find(larger_0p1>0.1))/length(larger_0p1)
%     
%     larger_0_vertices = length(find(larger_0>0.01))/length(larger_0)
% %     
% % %     mr_parms = [tr flipangle te ti]
%     mr_parms = [2000 10 35 0];
%      size_vol = size(vol);
% % %     vol_result = reshape(vol,116414,size_vol(1),size_vol(2),size_vol(3),1)
%     fname = 'test.mgz';
%       vol_larger_0p1 = zeros(size_vol(1),size_vol(2),size_vol(3),1);
%       vol_larger_0p1(finger_label_vertices_matlab,1,1,1) =  larger_0p1;
% %       r = save_mgh(vol_larger_0p1, fname, M, mr_parms);
%     
%     
% end

% total_percentage_zero = length(find(time_series_in_label(:)==0))/length(time_series_in_label(:))
% 
% total_percentage_larger_one = length(find(time_series_in_label(:)>0.01))/length(time_series_in_label(:))
% 
% total_percentage_larger_ten = length(find(time_series_in_label(:)>0.1))/length(time_series_in_label(:))
% 
% hist(time_series_in_label(:),100)

% sprintf('****************************************************************')
% subplot(5,1,1)
%  vertex_tksurfer = 55003;
%  vertex_matlab   = vertex_tksurfer+1;
%  series = reshape(vol(vertex_matlab,:,:,:),1,frame_number);
%  larger_zero = length(find(series>0))
%  mean_gm     = mean(series)
%  plot(series)
%  
% subplot(5,1,2)
%  vertex_tksurfer = 55005;
%  vertex_matlab   = vertex_tksurfer+1;
%  series = reshape(vol(vertex_matlab,:,:,:),1,frame_number);
%  larger_zero = length(find(series>0))
%  mean_gm     = mean(series)
%  plot(series)
%  
% subplot(5,1,3)
%  vertex_tksurfer = 56990;
%  vertex_matlab   = vertex_tksurfer+1;
%  series = reshape(vol(vertex_matlab,:,:,:),1,frame_number);
%  larger_zero = length(find(series>0))
%  mean_gm     = mean(series)
%  plot(series)
%  
% subplot(5,1,4)
%  vertex_tksurfer = 55042;
%  vertex_matlab   = vertex_tksurfer+1;
%  series = reshape(vol(vertex_matlab,:,:,:),1,frame_number);
%  larger_zero = length(find(series>0))
%  mean_gm     = mean(series)
%  plot(series)
%  
% subplot(5,1,5)
%  vertex_tksurfer = 56122;
%  vertex_matlab   = vertex_tksurfer+1;
%  series = reshape(vol(vertex_matlab,:,:,:),1,frame_number);
%  larger_zero = length(find(series>0))
%  mean_gm     = mean(series)
%  plot(series)
