%%
clear all; clc;
%%   
script_dir    = pwd;
subjects_dir  = getenv('SUBJECTS_DIR');

subject_list  = {'Subject_01_ID_from_recon-all'
	             'Subject_02_ID_from_recon-all'
	             'Subject_03_ID_from_recon-all'}; %exactly the same string as in file A_...


finger        = 'NAME OF EXPERIMENT (abbreviation like D1_left_hand)'; %exactly the same string as in file A_...	   

cortical_depths_for_sampling = [0 0.3 0.6]; %distance projection along normal



		   
for j = 1:length(subject_list)
    
    subject_name      = char(subject_list(j));
    
    cd(sprintf('%s/%s',script_dir,subject_name));
    maindir           = pwd;
    workdir           = sprintf('%s/workdir',maindir);
    fractions_data    = sprintf('%s/04_fractions_%s',workdir,finger);
    matrices_dir      = sprintf('%s/02_%s_%s',workdir,'matrices',finger);
    filename          = 'IM-*.cortex.mgz';
    path_and_filename = sprintf('%s/%s',fractions_data,filename);
    listing           = dir(path_and_filename);

    
    
	for depth_index = 1:length(cortical_depths_for_sampling)
        
        		       cortical_depths_for_sampling_reduced = 1000*cortical_depths_for_sampling(depth_index);
    
        frame_mod_dir = sprintf('%s/05_fractions_mod_%s_fractions_gm_depth_%05i_microns',workdir,finger,cortical_depths_for_sampling_reduced);
    
        %% 
        if exist(sprintf('%s',frame_mod_dir)) == 0
           system(sprintf('mkdir %s',frame_mod_dir));
        end 

        % Transformation from Volume to surface
        for i = 1:length(listing) 
               
            frame_focus = sprintf('IM-%04i.cortex.mgz',i); % was gm instead of cortex in FreeSurfer 5.3
            frame_focus = listing(i).name; % was gm instead of cortex in FreeSurfer 5.3


            
            functional_reg = sprintf('%s/register.f%03i.dof6.dat',matrices_dir,i); 
               
            if exist(sprintf('%s/%s',frame_mod_dir,frame_focus)) == 0
               system(sprintf('mri_vol2surf --mov %s/%s --reg %s --interp nearest --projfrac %f --hemi rh --o %s/%s --noreshape --cortex',...
               fractions_data,frame_focus,functional_reg,...
               cortical_depths_for_sampling(depth_index),frame_mod_dir,...
               frame_focus));
               sprintf('mri_vol2surf --mov %s/%s --reg %s --interp nearest --projfrac %f --hemi rh --o %s/%s --noreshape --cortex',...
               fractions_data,frame_focus,functional_reg,...
               cortical_depths_for_sampling(depth_index),frame_mod_dir,...
               frame_focus)   
            end
               
        end
        
        system(sprintf('mri_concat --i %s/IM-*.cortex.mgz --o %s/fractions.sm0.self.rh.mgz',...
               frame_mod_dir,frame_mod_dir))
                        
        system(sprintf('mri_convert -tr 2000 %s/fractions.sm0.self.rh.mgz %s/fractions.sm0.self.rh.mgz',...
               frame_mod_dir,frame_mod_dir))  
        
    end
end

cd(script_dir);
